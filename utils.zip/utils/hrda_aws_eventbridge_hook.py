from typing import Optional, List, Iterable

from airflow import AirflowException
from airflow.providers.amazon.aws.hooks.base_aws import AwsBaseHook


class HRDAAwsEventBridgeHook(AwsBaseHook):
    """
    Interact with AWS EventBridge.

    """

    def __init__(
        self, *args, table_keys: Optional[List] = None, table_name: Optional[str] = None, **kwargs
    ) -> None:
        kwargs["client_type"] = "events"
        super().__init__(*args, **kwargs)

    def send_events(self, entries: Iterable) -> bool:
        """Write batch items to DynamoDB table with provisioned throughout capacity."""
        try:
            response = self.get_conn().put_events(Entries=entries)
            return True
        except Exception as general_error:
            raise AirflowException(f"Failed to send events to EventBridge, error: {str(general_error)}")