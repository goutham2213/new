import re
import json
from airflow.providers.amazon.aws.hooks.s3 import S3Hook
from airflow.operators.bash import BashOperator


def parse_s3_event_metadata(
        sensor_task_id: str,
        sensor_xcom_key: str,
        report_prefix_xcom_key: str,
        report_name_xcom_key: str,
        report_data_date_xcom_key: str,
        destination_file_name_xcom_key: str,
        inbound_bucket: str,
        report_prefixes: list,
        **context: dict
    ) -> None:

    ti = context['task_instance']

    raw_return = ti.xcom_pull(
        task_ids=sensor_task_id,
        key=sensor_xcom_key,
        )

    event_metadata=json.loads(raw_return[0]['Body'])
    bucket = event_metadata['Records'][0]['s3']['bucket']['name']
    if bucket != inbound_bucket:
        raise Exception(f"Receiving events for unknown bucket: {bucket}.\n Expected bucket {inbound_bucket}")

    key = event_metadata['Records'][0]['s3']['object']['key']
    key_lower = key.lower()
    for report_prefix in report_prefixes:
        if key_lower.startswith(report_prefix):
            
            # Searching and extracting from report key the pattern [report_name]_20YYMMDD
            re_date_pattern = re.compile(r'%s_{1,}20\d{6}' % report_prefix)
            re_search_results = re.search(re_date_pattern, key_lower)
            if not re_search_results:
                raise Exception(f"Could not extract data date from key: {key} with re search results: {re_search_results}")
            data_date = re_search_results.group(0).split('_')[-1]

            if '/' in report_prefix:
                report_prefix = report_prefix.split('/')[-1]

            if '/' in key:
                report_name_no_slash = key.split('/')[-1]
            else:
                report_name_no_slash = key
            
            ti.xcom_push(key=report_prefix_xcom_key, value=report_prefix)
            ti.xcom_push(key=report_name_xcom_key, value=key)
            ti.xcom_push(key=report_data_date_xcom_key, value=data_date)
            ti.xcom_push(key=destination_file_name_xcom_key, value=report_name_no_slash)
            print('su')
            return None
    else:
        raise Exception(f"Unknown file dropped in bucket '{bucket}' with name: '{key}'")


def chk_s3_obj_nonempty(bucket: str = '', prefix: str = '') -> bool:
    '''
    Checks S3 object metadata to see if object is 0 Byte
    '''
    s3_hook = S3Hook()
    keys = s3_hook.list_keys(bucket_name=bucket, prefix=prefix)
    size_of_keys = [s3_hook.get_key(key, bucket).content_length for key in keys]
    return any([ n > 0 for n in size_of_keys])

def call_bashop(task_id):
    BashOperator(
        bash_command='echo bash_task: {{ dag_run.conf.file_key }}, {{dag_run.conf.file_key2}}, {{ dag_run.logical_date | ds }}'
    )
    return 'success'



