import re
import time
import json
from typing import Union, List
from datetime import datetime
import pandas as pd
from airflow.utils.state import DagRunState
from airflow.utils.session import create_session
from airflow.models.dagrun import DagRun
from airflow.models.variable import Variable
from airflow.providers.amazon.aws.hooks.dynamodb import AwsDynamoDBHook

from utils.edp_aws_eventbridge_hook import EDPAwsEventBridgeHook
from utils.redshift import write_metrics


class FileMixin:
    '''
    Description: Mixin class inherited by other classes or used within modules to produce filenames, object paths, etc. 
    Some classmethods will accept Airflow macro formatted strings for date & time parameters.

    '''

    DATETIME_ISO_FMT = '%Y-%m-%dT%H:%M:%S'
    DATETIME_NODASH_FMT = DATETIME_ISO_FMT.replace('-', '').replace('T', '').replace(':', '')
    DATE_FMT = '%Y-%m-%d'
    AIRFLOW_MACROS_RE = r'{{\s*(ds|ts_nodash|macros.dateutil.parser.parse\(.*\)\.date\(\)\.isoformat\(\))\s*}}'
    COMPILED_MACRO_PATTERN_RE = re.compile(AIRFLOW_MACROS_RE)
    DATALAKE_ZONES = ["gold", "silver", "bronze","tmp"]

    @staticmethod
    def get_date_str(
            snapshot_dt_obj: Union[str, datetime],
            dt_file_fmt: str,
            compiled_re_pat: re.Pattern
    ) -> str:

        '''
        Description: Static method used to render datetime.datetime objects into string values. The method
        ignores and returns Airflow macros passed to the 'snapshot_dt_obj' argument.

        '''

        if isinstance(snapshot_dt_obj, datetime):
            return snapshot_dt_obj.strftime(dt_file_fmt)
        elif isinstance(snapshot_dt_obj, str) and re.match(compiled_re_pat, snapshot_dt_obj):
            return snapshot_dt_obj
        else:
            raise Exception(f"Invalid choice of 'snapshot_datetime' argument with value: {snapshot_dt_obj}")

    @classmethod
    def filename_snapshot(
            cls,
            source: str,
            snapshot_datetime: Union[str, datetime],
            file_ext: str = 'csv',
            compression: str = None,
            source_extra_ids: List[str] = None
    ) -> str:

        '''
        Description: Class method used to name files representing snapshots. Snapshots represent
        the logical data date. The 'source_extra_ids' argument should contain additional logical string values
        used to name the file.

        '''

        date_str = cls.get_date_str(
            snapshot_datetime,
            cls.DATETIME_NODASH_FMT,
            cls.COMPILED_MACRO_PATTERN_RE
        )

        return f'{source.lower()}' \
               f'{"_" + "_".join(source_extra_ids) if source_extra_ids is not None else ""}' \
               f'_{date_str}.{file_ext.lower().strip()}' \
               f'{"." + compression.lower().strip() if compression is not None else ""}'

    @classmethod
    def filename_incremental(
            cls,
            source: str,
            start_datetime: Union[str, datetime],
            end_datetime: Union[str, datetime],
            file_ext: str = 'csv',
            compression: str = None,
            source_extra_ids: List[str] = None
    ) -> str:

        '''
        Description: Class method used to name files representing data with date ranges. The date range
        represents the logical data date. The 'source_extra_ids' argument should contain additional logical string values
        used to name the file.

        '''

        start_datetime_str = cls.get_date_str(
            start_datetime,
            cls.DATETIME_NODASH_FMT,
            cls.COMPILED_MACRO_PATTERN_RE
        )

        end_datetime_str = cls.get_date_str(
            end_datetime,
            cls.DATETIME_NODASH_FMT,
            cls.COMPILED_MACRO_PATTERN_RE
        )

        return f'{source.lower()}' \
               f'{"_" + "_".join(source_extra_ids) if source_extra_ids is not None else ""}' \
               f'_{start_datetime_str}_{end_datetime_str}.{file_ext.lower().strip()}' \
               f'{"." + compression.lower().strip() if compression is not None else ""}'

    @classmethod
    def blob_prefix(
            cls,
            source_system= None ,
            event_date: Union[str, datetime] = None,
            extra_part_kv: dict = {},
            extra_source_kv: dict = {}
    ) -> str:

        '''
        Description: Class method used to create object prefixes, where objects are located within the Data Lake.
        The 'zone' argument represents the quality of the data within the object. The 'extra_part_kv' arg
        should be a dictionary containing key-value pairs that will be rendered into Hive style partitions and added
        to the object's path

        '''

        if event_date is not None:
            event_date_str = cls.get_date_str(
                event_date,
                cls.DATETIME_ISO_FMT,
                cls.COMPILED_MACRO_PATTERN_RE
            )

        # zone = zone.lower().strip()
        # if zone not in cls.DATALAKE_ZONES:
        #     raise Exception(f"Invalid 'zone' argument with value: {zone}")

        if event_date is not None:
            date_str = cls.get_date_str(
                event_date,
                cls.DATE_FMT,
                cls.COMPILED_MACRO_PATTERN_RE
            )

        if source_system is None:
            blob_prefix = ''
        else:
            blob_prefix = '/'.join([f"{source_system}"])

        if extra_source_kv:
            source_kv_str = '/'.join([f"{key}={value}" for key, value in extra_source_kv.items()])
            if blob_prefix == '':
                blob_prefix = source_kv_str
            else:
                blob_prefix = '/'.join([blob_prefix, source_kv_str])

        if event_date is None:
            pass
        else:
            blob_prefix = '/'.join([blob_prefix, f"event_date={date_str}"])

        if extra_part_kv:
            partition_kv_str = '/'.join([f"{key}={value}" for key, value in extra_part_kv.items()])
            blob_prefix = '/'.join([blob_prefix, partition_kv_str])

        print(f"printing the blob_prefix{blob_prefix}")

        return blob_prefix


def write_to_job_control_table(
        job_id: str,
        event_id: str,
        config: str
) -> None:
    '''
        Description: Method to write the Job stats data into Job Control Table.

    '''
    Items = [{
        "process_id": job_id,
        "config": config,
        "event_id": event_id
    }]
    table = AwsDynamoDBHook(table_name=f"edp-job-control-{Variable.get('EDP_ENV')}", table_keys=["process_id", "event_id"])
    table.write_batch_data(Items)

def send_event(dag_id, run_date, state, reason=None):
    env = Variable.get('EDP_ENV')
    if state == 'success':
        detail = f'edpdagsuccess{env}'
        status = 'succeeded'
    elif state == 'failed':
        detail = f'edpdagfailure{env}'
        status = 'failed'
    elif state == 'rejected':
        detail = f'edpdagrejected{env}'
        status = 'rejected'
    client = EDPAwsEventBridgeHook()
    client.send_events(entries=[
        {
            'Detail': json.dumps({
                "dag_id": dag_id,
                "state": status,
                "run_date": run_date,
                "reason": reason
            }),
            'DetailType': detail,
            'Source': 'com.amazonaws.us-west-2.airflow'
        }
    ])

def dag_callback(
        context
) -> None:
    '''
        Description: Callback method that will be called when a DAG is succeeded or Failed.
        Writes the status and metrics to the DynamoDB Job Control Table
    '''
    try:
        dag_id = f"{context['dag'].dag_id}"
        job_id = f"ad_{dag_id}"
        event_id = f"adm_{context['ts_nodash'].replace('T', '')}"

        stats = {}
        stats['run_date'] = f"{context['ds_nodash']}"
        stats['state'] = f"{context['dag_run'].state}"
        stats['start_time'] = f"{context['dag_run'].start_date}"
        stats['end_time'] = f"{context['dag_run'].end_date}"
        stats['duration'] = f"{round((context['dag_run'].end_date - context['dag_run'].start_date).total_seconds(), 2)}"
        stats['reason'] = f"{context['reason']}"
        stats_str = json.dumps(stats)
        write_to_job_control_table(job_id, event_id, stats_str)
        send_event(dag_id, stats['run_date'], stats['state'], stats['reason'])
        context['ti'].xcom_push(key='dag', value='Completed Dag Callback Successfully')
    except Exception as e:
        context['ti'].xcom_push(key='dag', value=str(e))


def print_dag_stats(**kwargs):
    col_list = ['task_id', 'run_date', 'start_date', 'end_date', 'duration', 'state', 'read_records',
                'processed_records', 'rejected_records', 'dup_records']
    ti = kwargs['ti']
    print(f'printing ti{ti}')
    stats_list = []
    for task_id in ti.task.dag.task_ids:
        if 'glue_job_' in task_id:
            task_stats = ti.xcom_pull(task_ids=[task_id], key='stats')
            if task_stats[0]:
                stats_list.append(task_stats[0])
                print(f'printing the stats_list in if{stats_list}')

            else:
                stats_list.append({'task_id': task_id, 'state': 'skipped'})
                stats = {'dag_id': kwargs['dag'].dag_id, 'dagrun_id': kwargs['dag_run'].run_id, 'task_id': task_id,
                         'state': 'skipped', 'run_date': kwargs['ds']}
                print(f'printing the stats_list in else{stats_list}')
                #write_metrics(stats)
    stats_final = [stats for stats in stats_list if stats]
    stats = pd.DataFrame(stats_final)
    for col in col_list:
        if col not in stats:
            stats[col] = ''
    stats = stats[col_list]
    stats = stats.sort_values("task_id").fillna('')
    stats["rejected_records"] = stats["rejected_records"].fillna(0)
    print('DAG Summary\n\n' + stats.to_markdown(index=False))
    # if int(stats.sum()["rejected_records"]) > 0:
    #     send_event(kwargs['dag'].dag_id, kwargs['ds'], 'rejected', f'rejected records : {stats.sum()["rejected_records"]}')


def check_dagrun_status(
        dag_id: str,
        dag_run_id: str,
        dag_run_execution_dt: str,
        poke_interval_seconds: int,
        **context
) -> None:
    dag_running_states = [DagRunState.QUEUED, DagRunState.RUNNING]
    with create_session() as session:
        dag_run = session.query(DagRun).filter(
            DagRun.dag_id == dag_id,
            DagRun.run_id == dag_run_id
        ).first()

    if dag_run is None:
        print(
            f"Dag run id '{dag_run_id}' does not exist.\nScheduling dag '{dag_id}' with parameters: \nexecution date -- '{dag_run_execution_dt}'\ndag run id -- '{dag_run_id}'")
    else:
        current_dag_state = dag_run.get_state()
        while current_dag_state in dag_running_states:
            print(f"Dag currently in state: '{current_dag_state}'. Going to sleep for {poke_interval_seconds} seconds")
            time.sleep(poke_interval_seconds)

            with create_session() as session:
                dag_run = session.query(DagRun).filter(
                    DagRun.dag_id == dag_id,
                    DagRun.run_id == dag_run_id
                ).first()

            post_sleep_dag_state = dag_run.get_state()
            print(f"Dag state after sleep cycle: '{post_sleep_dag_state}'")
            current_dag_state = post_sleep_dag_state
        print(f"Dag no longer in states: '{DagRunState.RUNNING}' or '{DagRunState.QUEUED}'.\nMoving to downstream task")

        return None