import logging

from airflow.configuration import ensure_secrets_loaded
from airflow.exceptions import AirflowNotFoundException
import redshift_connector

log = logging.getLogger(__name__)


def get_connection_from_secrets(conn_id: str):
    """
    Get connection by conn_id.
    :param conn_id: connection id
    :return: connection
    """
    for secrets_backend in ensure_secrets_loaded():
        try:
            conn = secrets_backend.get_connection(conn_id=conn_id)
            if conn:
                return conn
        except Exception:
            log.exception(
                'Unable to retrieve connection from secrets backend (%s). '
                'Checking subsequent secrets backend.',
                type(secrets_backend).__name__,
            )
            raise AirflowNotFoundException(
                f"The conn_id `{conn_id}` isn't defined")


def write_metrics(stats):
    """
    Write DAG Task Metrics to Redshift Table
    """
    sql = "insert into edpdev.gtmda.dag_metrics(dag_id, dagrun_id, task_id, jobrun_id, run_date, start_date, end_date, \
            duration, state, read_records, processed_records, rejected_records, dup_records) values (%s, %s, %s, \
            %s, to_date(%s,'YYYY-MM-DD'), to_timestamp(%s,'YYYY-MM-DD HH24:MI:SS.US'), \
            to_timestamp(%s,'YYYY-MM-DD HH24:MI:SS.US'), cast(%s as decimal(10,5)), %s, cast(%s as decimal(10)), \
            cast(%s as decimal(10)), cast(%s as decimal(10)), cast(%s as decimal(10)))"
    metric_keys = ["dag_id", "dagrun_id", "task_id", "jobrun_id", "run_date", "start_date", "end_date",
                   "duration", "state", "read_records", "processed_records",
                   "rejected_records", "dup_records"]
    metrics = []
    for key in metric_keys:
        if key in stats.keys():
            metrics.append(stats[key])
        else:
            metrics.append(None)
    metrics = tuple(metrics)
    db = get_connection_from_secrets('edp_gtm_rsdb_dev')
    conn = redshift_connector.connect(
        host=db.host, port=db.port, user=db.login, database=db.schema, password=db.password)
    cursor = conn.cursor()
    cursor.execute(sql, metrics)
    conn.commit()
