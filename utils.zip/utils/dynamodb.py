import json
import boto3
from boto3 import resource
from boto3.dynamodb.conditions import Key, Attr

# Declaring private variables used to perform operations by functions below
# dy : abbreviation for 'dynamodb'
_job_control_table_prefix = 'edp-job-control'
_job_log_table_prefix = 'edp-job-log'


def _get_dy_job_control_table(env: str) -> 'boto3.resource.Table':

    '''
    Description: Return an initialize object representing the DynamoDB jobcontrol table in the request environment.
    '''    
    dynamodb_res = boto3.resource('dynamodb')
    tablename = f"{_job_control_table_prefix}-{env.lower()}"
    table = dynamodb_res.Table(tablename)
    return table


def _get_dy_job_log_table(env: str) -> 'boto3.resource.Table':

    '''
    Description: Return an initialize object representing the DynamoDB jobcontrol table in the request environment.
    '''
    dynamodb_res = boto3.resource('dynamodb')
    tablename = f"{_job_log_table_prefix}-{env.lower()}"
    table = dynamodb_res.Table(tablename)
    return table


def put_job_control_entry(
        primary_key: str,
        sort_key: str,
        items: dict,
        env: str,
        **kwargs
    ) -> str:
    
    """
    Description: Instantiate a table resource object without actually creating a DynamoDB table. Note that the attributes 
    of this table are lazy-loaded: a request is not made nor are the attribute values populated until the attributes on the 
    table resource are accessed or its load() method is called.
    """
    Item={
            'process_id': primary_key,
            'event_id': sort_key,
            'items': items
        }
    for key in kwargs.keys():
        Item[key]=kwargs[key]
    control_table = _get_dy_job_log_table(env)
    item_response = control_table.put_item(
        Item=Item
    )
    print(f"Attempted to put item in DynamoDB log table {control_table} with response: {item_response}")
    return None


def get_job_config(
        process_id: str,
        event_id: str,
        env: str
    ) -> dict:
    
    '''
    Description: Function retrieves json formatted strings from dynamodb job-control table.
    Strings usually represent configurations, which are returned to caller as dict objects.
    Native JSON serializer and deserializer are utilized. 

    '''

    control_table = _get_dy_job_control_table(env)
    response = control_table.get_item(
        Key={
                "process_id": process_id,
                "event_id": event_id
            }
        )

    json_config_str = response['Item']['config']

    return json.loads(json_config_str)

def cdc_result_nonempty(primarykey: str, run_id: str, env: str, **kwargs) -> bool:
    table = _get_dy_job_log_table(env)
    response = table.query(
        KeyConditionExpression=Key("process_id").eq(f"{primarykey}")&Key("event_id").begins_with("gjm"),
        FilterExpression=Attr("run_id").eq(f"{run_id}")
    )
 
    return(any([False if metric['items']['processed_records']=='0' else True for metric in response['Items']]))

def get_job_stats(task_id: str, run_id: str, env: str):
    primarykey = f"gj_edp_{'_'.join(task_id.split('_')[3:])}"
    print(f"printing primarykey{primarykey}")
    print(f"run id is {run_id}")
    table = _get_dy_job_log_table(env)
    response = table.query(
        KeyConditionExpression=Key("process_id").eq(f"{primarykey}")&Key("event_id").begins_with("gjm"),
        FilterExpression=Attr("run_id").eq(f"{run_id}")
    )
    if response["Items"]:
        result = response["Items"][0]["items"]
    else:
        result = {
            'state' : 'N/A'
        }
    result["task_id"] = task_id
    result["run_id"] = run_id
    return result