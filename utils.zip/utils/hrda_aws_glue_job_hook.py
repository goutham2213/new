from airflow.providers.amazon.aws.hooks.glue import AwsGlueJobHook


class HrdaAwsGlueJobHook(AwsGlueJobHook):
    def __init__(
        self,
        *args,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        
    def get_job_run_info(self, job_name: str, run_id: str) -> str:
        glue_client = self.get_conn()
        job_run = glue_client.get_job_run(JobName=job_name, RunId=run_id, PredecessorsIncluded=True)
        return job_run
