from datetime import datetime
import os.path
import json
from urllib.parse import quote_plus
from typing import Optional
from airflow.models import BaseOperator
from airflow.providers.amazon.aws.hooks.s3 import S3Hook
from airflow.providers.amazon.aws.hooks.logs import AwsLogsHook
from airflow.exceptions import AirflowException

from utils.dynamodb import get_job_stats
from utils.edp_aws_glue_job_hook import EdpAwsGlueJobHook
from utils.redshift import write_metrics


class EdpAwsGlueJobOperator(BaseOperator):
    template_fields = ('script_args',)
    template_ext = ()
    template_fields_renderers = {
        "script_args": "json",
        "create_job_kwargs": "json",
    }
    ui_color = '#ededed'

    def __init__(
            self,
            *,
            job_name: str = 'aws_glue_default_job',
            job_desc: str = 'AWS Glue Job with Airflow',
            script_location: Optional[str] = None,
            concurrent_run_limit: Optional[int] = None,
            script_args: Optional[dict] = None,
            retry_limit: Optional[int] = None,
            num_of_dpus: int = 6,
            aws_conn_id: str = 'aws_default',
            region_name: Optional[str] = None,
            s3_bucket: Optional[str] = None,
            iam_role_name: Optional[str] = None,
            create_job_kwargs: Optional[dict] = None,
            run_job_kwargs: Optional[dict] = None,
            wait_for_completion: bool = True,
            **kwargs,
    ):
        super().__init__(**kwargs)
        self.job_name = job_name
        self.job_desc = job_desc
        self.script_location = script_location
        self.concurrent_run_limit = concurrent_run_limit or 1
        self.script_args = script_args or {}
        self.retry_limit = retry_limit
        self.num_of_dpus = num_of_dpus
        self.aws_conn_id = aws_conn_id
        self.region_name = region_name
        self.s3_bucket = s3_bucket
        self.iam_role_name = iam_role_name
        self.s3_protocol = "s3://"
        self.s3_artifacts_prefix = 'artifacts/glue-scripts/'
        self.create_job_kwargs = create_job_kwargs
        self.run_job_kwargs = run_job_kwargs or {}
        self.wait_for_completion = wait_for_completion
        self.task_id = kwargs['task_id']
        self.job_start_date = datetime.today()

    def execute(self, context):
        """
        Executes AWS Glue Job from Airflow
        :return: the id of the current glue job.
        """
        if self.script_location and not self.script_location.startswith(self.s3_protocol):
            s3_hook = S3Hook(aws_conn_id=self.aws_conn_id)
            script_name = os.path.basename(self.script_location)
            s3_hook.load_file(
                self.script_location, self.s3_artifacts_prefix + script_name, bucket_name=self.s3_bucket
            )
            s3_script_location = f"s3://{self.s3_bucket}/{self.s3_artifacts_prefix}{script_name}"
        else:
            s3_script_location = self.script_location
        glue_job = EdpAwsGlueJobHook(
            job_name=self.job_name,
            desc=self.job_desc,
            concurrent_run_limit=self.concurrent_run_limit,
            script_location=s3_script_location,
            retry_limit=self.retry_limit,
            num_of_dpus=self.num_of_dpus,
            aws_conn_id=self.aws_conn_id,
            region_name=self.region_name,
            s3_bucket=self.s3_bucket,
            iam_role_name=self.iam_role_name,
            create_job_kwargs=self.create_job_kwargs,
        )
        self.log.info(
            "Initializing AWS Glue Job: %s. Wait for completion: %s",
            self.job_name,
            self.wait_for_completion,
        )
        try:
            glue_job_run = glue_job.initialize_job(self.script_args, self.run_job_kwargs)
            if self.wait_for_completion:
                glue_job_run = glue_job.job_completion(self.job_name, glue_job_run['JobRunId'])
                self.log.info(
                    "AWS Glue Job: %s status: %s. Run Id: %s",
                    self.job_name,
                    glue_job_run['JobRunState'],
                    glue_job_run['JobRunId'],
                )
            else:
                self.log.info("AWS Glue Job: %s. Run Id: %s", self.job_name, glue_job_run['JobRunId'])
        except AirflowException as err:
            job_id = glue_job_run['JobRunId']
            self.log.info(f"fetching info for job run: {job_id}")
            self.log.error(
                '\n' + json.dumps(glue_job.get_job_run_info(self.job_name, glue_job_run['JobRunId']), indent=4,
                                  default=str))
            self.log.info(
                f"Output Logs : https://console.aws.amazon.com/cloudwatch/home#logsV2:log-groups/log-group/{quote_plus('/aws-glue/jobs/output')}/log-events/{glue_job_run['JobRunId']}")
            self.log.info(
                f"Error Logs : https://console.aws.amazon.com/cloudwatch/home#logsV2:log-groups/log-group/{quote_plus('/aws-glue/jobs/error')}/log-events/{glue_job_run['JobRunId']}")
            err_msg = str(err)
            stats = {"dag_id": self.dag_id,
                     "task_id": self.task_id,
                     "dagrun_id": self.script_args["--airflow_dagrun_id"],
                     "run_date": f"{self.script_args['--airflow_execution_date']}",
                     "start_date": f"{self.job_start_date}",
                     "end_date": f"{datetime.now()}",
                     "duration": f"{(self.job_start_date - datetime.now()).total_seconds()}",
                     "state": "failed",
                     "reason": err_msg}
            try:
                stats['jobrun_id'] = glue_job_run['JobRunId']
            except:
                stats['jobrun_id'] = None
            write_metrics(stats)
            raise

        job_id = glue_job_run['JobRunId']
        self.log.info(f"fetching info for job run: {job_id}")
        self.log.info('\n' + json.dumps(glue_job.get_job_run_info(self.job_name, glue_job_run['JobRunId']), indent=4,
                                        default=str))
        self.log.info(
            f"Output Logs : https://console.aws.amazon.com/cloudwatch/home#logsV2:log-groups/log-group/{quote_plus('/aws-glue/jobs/output')}/log-events/{glue_job_run['JobRunId']}")
        self.log.info(
            f"Error Logs : https://console.aws.amazon.com/cloudwatch/home#logsV2:log-groups/log-group/{quote_plus('/aws-glue/jobs/error')}/log-events/{glue_job_run['JobRunId']}")
        stats = get_job_stats(self.task_id, job_id, self.job_name.split('-')[-1])
        stats['dag_id'] = self.dag_id
        stats["dagrun_id"] = self.script_args["--airflow_dagrun_id"]
        stats["jobrun_id"] = glue_job_run['JobRunId']
        context['ti'].xcom_push(key='stats', value=stats)
        write_metrics(stats)
        return glue_job_run['JobRunId']

